using System;
using System.IO;

// First program
// MW, 5/1/04
public class FirstProgram
{
    public static void Main( string[ ] args )
    {
        Console.WriteLine( "Is there anybody out there?" );
    }
}