using System;

public class TestExiting
{
    // Suspend current program for a long time
    public static void Main( string[ ] args )
    {
        Console.WriteLine( "Testing1" );
        weiss.nonstandard.Exiting.LongPause( );
        Console.WriteLine( "Testing2" );
    }
}